pertemuan4/
├─ create.php   -> C: Create
├─ data.php
├─ delete.php   -> D: Delete
├─ edit.php     -> E: Edit
├─ form.php
├─ index.php    -> R: Read
├─ koneksi.php
├─ simpan.php
├─ store.php    -> S: Store
└─ update.php   -> U: Update